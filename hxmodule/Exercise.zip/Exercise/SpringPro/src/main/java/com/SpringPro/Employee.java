package com.SpringPro;

public class Employee {
 /* private int id;
  private String name;
  private int salary;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
*/  
	int var1=0;
	public void setVar1(int var1) {
		this.var1 = var1;
	}
	public int getVar1() {
		this.var1=var1+1;
		return var1;
	}
	public void init() {
		System.out.println("initialization");
		
	}
	public void destroy() {
		System.out.println("Destroy");
	}
}
