package com.SpringPro;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
    	Employee bean=(Employee)context.getBean("emp");
    	Employee bean1=(Employee)context.getBean("emp");
    	Employee bean2=(Employee)context.getBean("emp");
    	System.out.println(bean.getVar1());
    	System.out.println(bean1.getVar1());
    	System.out.println(bean2.getVar1());
	   // System.out.println(bean.getId());
	    //System.out.println(bean.getName());
	   // System.out.println(bean.getSalary());

    /*Resource res = new ClassPathResource("Beans.xml");
     BeanFactory fac = new XmlBeanFactory(res);
     Employee emp =(Employee)fac.getBean("emp");
     System.out.println(emp.getId());
	    System.out.println(emp.getName());
	    System.out.println(emp.getSalary());
	    */
    }
}
