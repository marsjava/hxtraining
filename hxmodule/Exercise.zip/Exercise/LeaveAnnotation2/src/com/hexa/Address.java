package com.hexa;

import javax.persistence.Embeddable;

@Embeddable

public class Address {
private int sNo;
private String city;
private String sName;
public int getsNo() {
	return sNo;
}
public void setsNo(int sNo) {
	this.sNo = sNo;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getsName() {
	return sName;
}
public void setsName(String sName) {
	this.sName = sName;
}

}
