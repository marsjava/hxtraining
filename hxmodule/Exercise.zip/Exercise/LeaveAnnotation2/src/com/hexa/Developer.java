package com.hexa;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="Dev")
@AttributeOverrides({
	@AttributeOverride(name="eId",column=@Column(name="EMP_ID")),
	@AttributeOverride(name="eName",column=@Column(name="EMP_NAME")),
	@AttributeOverride(name="salary",column=@Column(name="EMP_SALARY")),
})
public class Developer extends Employee{

private int mgrId;

public int getMgrId() {
	return mgrId;
}
public void setMgrId(int mgrId) {
	this.mgrId = mgrId;
}

}
