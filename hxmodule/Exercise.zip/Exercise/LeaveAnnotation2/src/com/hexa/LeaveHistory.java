package com.hexa;



import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="LeaveHis")
public class LeaveHistory {

        private int lId;
        private int noOfDays;
        private String reason;
        @Id
		public int getlId() {
			return lId;
		}
		public void setlId(int lId) {
			this.lId = lId;
		}
		
		public int getNoOfDays() {
			return noOfDays;
		}
		public void setNoOfDays(int noOfDays) {
			this.noOfDays = noOfDays;
		}
		
		public String getReason() {
			return reason;
		}
		public void setReason(String reason) {
			this.reason = reason;
			
		}
		@Embedded
		private Address address;
		public Address getAddress() {
			return address;
		}
		public void setAddress(Address address) {
			this.address = address;
		}
		
}
