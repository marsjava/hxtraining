
package com.hexa;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;


public class LeaveMain {

	public static void main(String[] args) {
		
		AnnotationConfiguration se = new AnnotationConfiguration();
		
		SessionFactory e =se.configure().buildSessionFactory();
		
		Session session = e.openSession();
		
		Transaction t = session.beginTransaction();
		/*Address a =new Address();
		a.setsNo(2);
		a.setCity("Abc");
		a.setsName("Area");
		
		LeaveHistory s = new LeaveHistory();
		s.setlId(39333);
		s.setNoOfDays(5);
		s.setReason("sick");
		s.setAddress(a);
		session.persist(s);
		*/
		
		Query query=session.createQuery("from com.hexa.LeaveHistory");
		List l =query.list();
		
	}

}
