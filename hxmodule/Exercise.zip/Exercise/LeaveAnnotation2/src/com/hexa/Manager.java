package com.hexa;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="Man")
@AttributeOverrides({
	@AttributeOverride(name="eId",column=@Column(name="EMP_ID")),
	@AttributeOverride(name="eName",column=@Column(name="EMP_NAME")),
	@AttributeOverride(name="salary",column=@Column(name="EMP_SALARY")),
})
public class Manager extends Employee {

private int depId;


public int getDepId() {
	return depId;
}
public void setDepId(int depId) {
	this.depId = depId;
}

}
