package com.Spring4;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

public static void main(String[] args) {
ApplicationContext context = 
	             new ClassPathXmlApplicationContext("Beans.xml");
JavaCollection jv=(JavaCollection)context.getBean("jc");
		System.out.println(jv.getList());

	}

}
