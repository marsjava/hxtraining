package com.Spring4;


import java.util.List;

public class JavaCollection {
	private List list;
	
	public void setList(List list) {
		this.list = list;
	}
	
	public List getList() {
		return list;
	}

}