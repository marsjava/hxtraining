package com.hexa;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Employee_Sur")
public class Employee {
		@Id
		@Column(name="EMP_ID")
		private int empId;
		@Column(name="EMP_NAME")
		private String empName;
		@Column(name="EMP_DEPT")
		private String empDept;
		@Column(name="MGR_ID")
		private int mgrId;
		@Column(name="EMP_LEAVE_BAL")
		private int empLeaveBal;
		public Employee() {
			
		}
		public Employee(int empId,String empName,String empDept,int mgrId,int empLeaveBal) {
			this.empId = empId;
			this.empName=empName;
			this.empDept=empDept;
			this.mgrId=mgrId;
			this.empLeaveBal=empLeaveBal;
			}
		public int getEmpId() {
			return empId;
		}
		public void setEmpId(int empId) {
			this.empId = empId;
		}
		public String getEmpName() {
			return empName;
		}
		public void setEmpName(String empName) {
			this.empName = empName;
		}
		public String getEmpDept() {
			return empDept;
		}
		public void setEmpDept(String empDept) {
			this.empDept = empDept;
		}
		public int getMgrId() {
			return mgrId;
		}
		public void setMgrId(int mgrId) {
			this.mgrId = mgrId;
		}
		public int getEmpLeaveBal() {
			return empLeaveBal;
		}
		public void setEmpLeaveBal(int empLeaveBal) {
			this.empLeaveBal = empLeaveBal;
		}

		
}
