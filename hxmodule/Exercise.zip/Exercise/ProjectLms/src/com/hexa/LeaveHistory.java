package com.hexa;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="LeaveHistory")
public class LeaveHistory {
@Column(name="EMP_ID")	
private int empId;
@Id
@Column(name="LEAVE_ID")	
private int leaveId;
@Column(name="NO_OF_DAYS")	
private int noOfDays;
@Column(name="LEAVE_TYPE")	
private String leaveType;
@Column(name="LEAVE_STATUS")	
private String leaveStatus;
@Column(name="START_DATE")	
private Date startDate;
@Column(name="END_DATE")	
private Date endDate;

public LeaveHistory(int empId,int leaveId,int noOfDays,String leaveType,String leaveStatus,Date startDate,Date endDate) {
	this.empId= empId;
	this.leaveId=leaveId;
	this.noOfDays=noOfDays;
	this.leaveType=leaveType;
	this.leaveStatus=leaveStatus;
	this.startDate=startDate;
	this.endDate=endDate;
}



public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public int getLeaveId() {
	return leaveId;
}
public void setLeaveId(int leaveId) {
	this.leaveId = leaveId;
}
public int getNoOfDays() {
	return noOfDays;
}
public void setNoOfDays(int noOfDays) {
	this.noOfDays = noOfDays;
}
public String getLeaveType() {
	return leaveType;
}
public void setLeaveType(String leaveType) {
	this.leaveType = leaveType;
}
public String getLeaveStatus() {
	return leaveStatus;
}
public void setLeaveStatus(String leaveStatus) {
	this.leaveStatus = leaveStatus;
}
public Date getStartDate() {
	return startDate;
}
public void setStartDate(Date startDate) {
	this.startDate = startDate;
}
public Date getEndDate() {
	return endDate;
}
public void setEndDate(Date endDate) {
	this.endDate = endDate;
}

}
