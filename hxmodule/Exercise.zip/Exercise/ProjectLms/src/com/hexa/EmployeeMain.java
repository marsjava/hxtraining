package com.hexa;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.hexa.Employee;

public class EmployeeMain {

	public static void main(String[] args) {
		
		
		AnnotationConfiguration ac =new AnnotationConfiguration();
		SessionFactory sf =ac.configure().buildSessionFactory();
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();
		Employee emp =new Employee();
		Employee emp1 =new Employee();
		emp.setEmpId(1012);
		emp.setEmpName("Surabhi");
		emp. setEmpDept("CS");
		emp.setMgrId(0);
		emp.setEmpLeaveBal(7);
		emp1.setEmpId(1013);
		emp1.setEmpName("Sia");
		emp1. setEmpDept("CS");
		emp1.setMgrId(1000);
		emp1.setEmpLeaveBal(7);
		session.persist(emp1);
		session.persist(emp);
		t.commit();
		
Query query = session.createQuery("FROM com.hexa.Employee");
		List l = query.list();
		Iterator<Employee> it = l.iterator();
		while (it.hasNext()) {
			emp=it.next();
			System.out.println("id"+ emp.getEmpId());
			System.out.println("empname"+ emp.getEmpName());
			System.out.println("empdep"+emp. getEmpDept());
			System.out.println("mgrid"+ emp.getMgrId());
			System.out.println("leavebal"+emp. getEmpLeaveBal());
			
		}
		

		session.close();

	}

}
