package com.hexa.Controller.LoginController;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginValidation
 */
@WebServlet("/LoginValidation")
public class LoginValidation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginValidation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	PrintWriter out =response.getWriter();
	out.println("<html>");
	out.println("<body>");
	out.println("<h1>");
	out.println("I am inside the servlet");
	out.println("</h1>");
	out.println("</body>");
	out.println("</html>");
	System.out.println("printed on console");
	String un =request.getParameter("user");
	out.println("hi"+ un+"welcome to web world");
	String pswd = request.getParameter("pass");
	String t = request.getParameter("type");
	
	if((un.equals("john"))&&(pswd.equals("delta")) && t.equals("Manager") ) {
	RequestDispatcher rd =request.getRequestDispatcher("Success");
	rd.forward(request,response);
	}
	
	else if((un.equals("thomas"))&&(pswd.equals("alfa")) && t.equals("Employee")) {
		RequestDispatcher rd =request.getRequestDispatcher("Success");
		rd.forward(request,response);
		}
		else {
			RequestDispatcher rd =request.getRequestDispatcher("Error.html");
			rd.forward(request,response);
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
