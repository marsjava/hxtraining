package hexa;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class StudentMain {

	public static void main(String[] args) {
		
		AnnotationConfiguration ac = new AnnotationConfiguration();
		
		SessionFactory sf = ac.configure("surabh.cfg.xml").buildSessionFactory();
		
		Session session = sf.openSession();
		
		Transaction t = session.beginTransaction();
		
		Student std = new Student();
		
		std.setSid(2595);
		std.setSname("Surabhi");
		session.persist(std);
		t.commit();

		Query query = session.createQuery("FROM hexa.Student");
		
		List l = query.list();
		Iterator<Student> it = l.iterator();
		while (it.hasNext()) {
			std=it.next();
			System.out.println(std.getSid());
			System.out.println(std.getSname());
		}
		
		session.close();
		
	}

}
