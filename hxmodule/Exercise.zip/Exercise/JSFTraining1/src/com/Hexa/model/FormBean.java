package com.Hexa.model;

import javax.annotation.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean
@RequestScoped
public class FormBean {
private String card;

public String getCard() {
	return card;
}

public void setCard(String card) {
	this.card = card;
}

}
