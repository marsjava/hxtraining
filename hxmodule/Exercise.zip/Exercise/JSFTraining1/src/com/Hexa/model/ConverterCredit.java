package com.Hexa.model;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;


@FacesConverter(value="cc")
public class ConverterCredit implements Converter {

	@Override
	public Object getAsObject(FacesContext arg0, UIComponent arg1, String arg2) {
		String card=arg2.trim();
		int credit=card.length();
		if(credit!=16) {
			throw new ConverterException(new FacesMessage("card value should be 16"));
		} else {
			String c1=card.substring(0,4);
			String c2=card.substring(4,8);
			String c3=card.substring(8,12);
			String c4=card.substring(12,16);
			StringBuffer sf = new StringBuffer();
			sf.append(c1+"-");
			sf.append(c2+"-");
			sf.append(c3+"-");
			sf.append(c4);
			return sf.toString();
		}
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {
		// TODO Auto-generated method stub
		return null;
	}

}
