package com.Spring5;

public class Shop {
	private Books book;
	public Shop() {
		System.out.println("in good shop");
	}
	public void setBook(Books book) {
	this.book=book;	
	}
	public Books getBook() {
return book;
	}
void getBooks() {
	book.getDetails();
}

}
