package com.Spring5;

public class Books {
public Books() {
	System.out.println("we are in good books");
}
public void getDetails() {
	System.out.println("famous books available");
}
}
