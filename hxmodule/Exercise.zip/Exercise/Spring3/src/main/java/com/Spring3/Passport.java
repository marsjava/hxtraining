  package com.Spring3;

public class Passport {
	private Aadhar aadhar;
public void setPassport(Aadhar aadhar) {
	
	this.aadhar=aadhar;
}
public void call()
{
	aadhar.getAadhar();
}
public Aadhar getAadhar() {
	return aadhar;
}
public void setAadhar(Aadhar aadhar) {
	this.aadhar = aadhar;
}
}

