package com.Spring3;

public class Aadhar {
	private Aadhar aadhar;
public Aadhar() {
	System.out.println("AAdhar is mandatory");
}
public void getAadhar() {
	System.out.println("Aadhar is provided by state govt.");
}
 
 
}
