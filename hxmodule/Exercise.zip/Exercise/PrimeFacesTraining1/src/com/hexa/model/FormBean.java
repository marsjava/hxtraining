package com.hexa.model;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean
@RequestScoped
public class FormBean {
private String name;
int count;
String technology;
public String getTechnology() {
	return technology;
}

public void setTechnology(String technology) {
	this.technology = technology;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
public int getCount() {
	return count;
}

public void setCount(int count) {
	this.count = count;
}
 public void ajaxLis() {
	name=name.toUpperCase();
	 name=name.concat("G");
 }
public void increment() {
	count++;
 }

public List techList() {
	ArrayList<String> ls=new ArrayList();
	ls.add("Angular");
	ls.add("Java");
	ls.add("Ajax");
	ls.add("Asp.net");
	
	return ls;
}





}
