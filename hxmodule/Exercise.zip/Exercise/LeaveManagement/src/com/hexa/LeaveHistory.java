package com.hexa;




public class LeaveHistory {

        private int lId;
        private int noOfDays;
        private String reason;
     
		public int getlId() {
			return lId;
		}
		public void setlId(int lId) {
			this.lId = lId;
		}
		
		public int getNoOfDays() {
			return noOfDays;
		}
		public void setNoOfDays(int noOfDays) {
			this.noOfDays = noOfDays;
		}
		
		public String getReason() {
			return reason;
		}
		public void setReason(String reason) {
			this.reason = reason;
		}
}
