package com.hexa;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class LeaveMain {

	public static void main(String[] args) {
		
		Configuration se = new Configuration();
		se.configure("hibernate.cfg.xml");
		SessionFactory e =se.buildSessionFactory();
		
		Session session = e.openSession();
		
		Transaction t = session.beginTransaction();
		
		LeaveHistory s = new LeaveHistory();
		s.setlId(39333);
		s.setNoOfDays(5);
		s.setReason("sick");
		session.persist(s);
		
		t.commit();
		
		session.close();
	
	}

}
