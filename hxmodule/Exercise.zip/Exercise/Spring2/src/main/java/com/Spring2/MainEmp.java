package com.Spring2;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainEmp {

	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
		PerEmployee o=(PerEmployee)context.getBean("b");
		//Employee e =(Employee)context.getBean("a");
		//System.out.println(e.getEmpName());
		System.out.println(o.getEmpId());
		System.out.println(o.getEmpName());
		System.out.println(o.getSalary());
		System.out.println(o.getDesignation());
	}

}
