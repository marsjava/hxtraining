package java8training;
interface Proto{
	public Proto doClone();
}
class Person implements Proto{
	String name;
	Person(String name){
		this.name=name;
	}
	@Override
	public Proto doClone() {
		return new Person("Arun");
	}
	public String toString() {
		return name;
	}
}
public class ProtoType {
	public static void main(String args[]) {
		Person perObj1 = new Person("Thomas");
		System.out.println(perObj1);
		Person perObj2 = (Person)perObj1.doClone();
		System.out.println(perObj2.doClone());
	}
  
}
