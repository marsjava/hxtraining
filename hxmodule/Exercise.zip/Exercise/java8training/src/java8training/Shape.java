package java8training;

public interface Shape {
	public void draw();

}
