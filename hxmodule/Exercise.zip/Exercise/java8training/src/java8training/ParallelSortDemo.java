package java8training;

import java.util.Arrays;

public class ParallelSortDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int arr[] = {22,56,12,54,67};
Arrays.parallelSort(arr);
for(int g:arr)
	System.out.println(g);
	}

}
