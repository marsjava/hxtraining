package java8training;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
public class ProductCollection {
	public static void main(String args[]) {
		List <Product> p= new ArrayList<>();
		
		Product p1=new Product("shoes",4 ,1000);
		Product p2 = new Product("brush",5,20);
		Product p3=new Product("watch",2,1200);
		Product p4= new Product("mobphone",6,12000);
		
		p.add(p1);
		p.add(p2);
		p.add(p3);
		p.add(p4);
	
for( Product pro:p) {
	System.out.println(pro.getName() +" "+pro.getId() +" " +pro.getPrice());
}
List<Integer> list =p.stream().filter(a->a.getPrice()>=3000).map(s->s.getPrice()).collect(Collectors.toList());
System.out.println("new list:"+list);
p.stream()
.filter(r->r.getName().startsWith("w"))
.forEach(r->System.out.println(r.getName()));
}
}
