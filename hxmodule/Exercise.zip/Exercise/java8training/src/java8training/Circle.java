package java8training;

public class Circle implements Shape{
	@Override
	public void draw() {
		System.out.println("Circle is drawn");
	}

}
class Square implements Shape{
	@Override
	public void draw() {
		System.out.println("Square is drawn");
	}
}
class DrawShape{
	public Shape selectTheShape(String str) {
		if(str.equals("circle")) {
			return new Circle();
			
		} else {
			return new Square();
		}
		
	}
}
