package java8training;

import java.util.StringJoiner;

public class StringJoinerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
StringJoiner sj = new StringJoiner("-");
sj.add("benz");
sj.add("we");
sj.add("hat");
sj.add("yup");
System.out.println(sj);
	}

}
