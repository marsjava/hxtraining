package java8training;
class Addition{
int add( int a, int b) {
	return a+b;
}
}
public class Demo {
public static void main(String args[]) {
	System.out.println("welcome to java 8");
	Addition add = new Addition();
	 int j= add.add(3, 4);
	System.out.println(j);
}
}
