package java8training;

public class Product {
  private String productName;
  private int productId;
 private int productPrice;
 Product( String name, int id, int price){
	 productName=name;
	 productId=id;
	 productPrice=price;
 }
 public void setName() {
	 productName="Tv";
	 
 }
 public String getName() {
	 return productName;
	 
 }
 public void setId() {
	 productId=1;
	 
 }
 public int getId() {
	 return productId;
	 
 }
 public void setPrice() {
	 productPrice=250;
	 
 }
 public int getPrice() {
	 return productPrice;
	 
 }
}
