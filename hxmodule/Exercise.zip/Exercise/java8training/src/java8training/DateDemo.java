package java8training;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;

public class DateDemo {
public static void main(String args[]) {
	LocalDate d = LocalDate.now();
	System.out.println("Date:"+ d);
	LocalTime t = LocalTime.now();
	System.out.println("Time:"+t);
	LocalDateTime dt = LocalDateTime.now();
	System.out.println("date and time" + dt);
	LocalDate s =LocalDate.now().plusDays(10);
	System.out.println("after 10 days:" +s);
	LocalDate d1 = LocalDate.now().minusMonths(2);
	System.out.println("2 months before"+d1);
	LocalDate ld =LocalDate.parse("2017-12-25").withMonth(4);
	System.out.println(ld);
	Period p =Period.between(d, ld);
	System.out.println(p);
}
}
