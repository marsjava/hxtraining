package java8training;
@FunctionalInterface
public interface Display {
public String message(String msg);

}
