package java8training;

public class SingletonDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Account a =Account.getInstance();
a.setBankName("SBI");
a.display();
}
	}


 class Account{
	 private String bankName;
	 private static Account acc = new Account();
	 private Account() {
		 
		 
	 }
	 public String getBankName() {
		 return bankName;
	 }
	 public void setBankName(String bankName) {
		 this.bankName=bankName;
	 }
	 public void display() {
		 System.out.println(getBankName());
	 }
	 public static Account getInstance() {
		 return acc;
	 }
 }