package java8training;

import java.util.Optional;

public class OptionalDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String[] s =new String[10];
Optional opt = Optional.ofNullable(s[1]);
if(opt.isPresent()) {
	String  g=s[1].substring(1,2);
	System.out.println(g);
}
else {
	System.out.println("There is no value in thye variable");
}
	}

}
