var value=function(){
	console.log("Welcome to java 8 Java Script");
	
}value();