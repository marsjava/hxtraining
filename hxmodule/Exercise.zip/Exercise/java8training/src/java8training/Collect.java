package java8training;

import java.util.List;
import java.util.stream.Stream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
public class Collect {
public static void main(String args[]) {
	List l = new ArrayList();
	l.add("abc");
	l.add("def");
	l.add("asd");
	//Iterator i = l.iterator();
	//while (i.hasNext()) {
	//System.out.println(i.next());
	 l.forEach(s-> System.out.println(s));
	Arrays.asList(23,34,56,78).forEach(e->System.out.println(e));
	
Display dis = new Display() {
	@Override 
	public String message(String msg) {
		return msg;
	}
};
System.out.println(dis.message("hi all"));
	Display play=s->s;
	System.out.println(play.message("hi"));
	
	
	

Operation op =new Operation() {
     @Override
     public int calculate(int n1, int n2) {
    	 return n1+n2;
     }
       
};
   System.out.println(op.calculate(2, 3));
   Operation o = (n1,n2)->n1+n2;
   System.out.println(o.calculate(4, 5));
   
   
   

Thread t = new Thread(new Runnable() {
	@Override
	public void run() {
		System.out.println("Thread is running...");
	}
});
t.run();
Thread t1=new Thread(()-> System.out.println("new Thread"));
t1.run();



Character c =new Character() {
	@Override
	public int noOfChar(String a) {
		return a.length();
	}
	
	};
System.out.println(c.noOfChar("Surabhi"));
Character c1= S-> (S.length());
System.out.println(c1.noOfChar("Surabhi")); 




List w = new ArrayList<Integer>();
for(int i =1;i<=20;i++) {
	w.add(i);
}

Stream<Integer> sequence = w.stream();
Stream<Integer> parallel = w.parallelStream();

Stream<Integer> seq =sequence.filter(p->p>10);
Stream<Integer> par =parallel.filter(p->p>10);
System.out.println("seq data");
seq.forEach(s->System.out.println(s));
System.out.println("parallel data");
par.forEach(s->System.out.println(s));
}

}