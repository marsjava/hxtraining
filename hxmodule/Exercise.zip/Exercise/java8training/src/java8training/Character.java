package java8training;

public interface Character {
public int noOfChar(String a);
}
