
package com.hexa;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;


public class LeaveMain {

	public static void main(String[] args) {
		
		AnnotationConfiguration se = new AnnotationConfiguration();
		
		SessionFactory e =se.configure().buildSessionFactory();
		
		Session session = e.openSession();
		
		Transaction t = session.beginTransaction();
		/*Address a =new Address();
		a.setsNo(2);
		a.setCity("Abc");
		a.setsName("Area");
		
		LeaveHistory s = new LeaveHistory();
		s.setlId(39333);
		s.setNoOfDays(5);
		s.setReason("sick");
		s.setAddress(a);
		session.persist(s);
		*/
		
		Employee emp =new Employee();
		emp.seteId(1);
		emp.seteName("sur");
		emp.setSalary(1000);
		emp.seteId(2);
		emp.seteName("sia");
		emp.setSalary(2000);
		
		
		Manager m = new Manager();
		m.seteId(12);
		m.seteName("sur");
		m.setSalary(1008);
		m.setDepId(101);
	
		
		Developer d =new Developer();
		d.seteId(21);
		d.seteName("sia"); 
		d.setSalary(2000);
		d.setMgrId(102);
		session.persist(emp);
		session.persist(m);
		session.persist(d);
		
		t.commit();
		
		session.close();
	
	}

}
