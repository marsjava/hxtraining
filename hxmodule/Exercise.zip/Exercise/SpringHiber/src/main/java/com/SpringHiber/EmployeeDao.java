package com.SpringHiber;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.SpringHiber.Employee;

public class EmployeeDao {
	private SessionFactory sessionFactory;
	private Session session;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	public void setSession(Session session) {
		this.session = session;
	}
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	public Session getSession()
	{
		 session = sessionFactory.openSession();
		return session;
				
	}
	public void storeEmp(Employee emp) {
		
		Session session = getSession();
		Transaction tran = session.getTransaction();
		tran.begin();

			session.save(emp);
		
		tran.commit();
		System.out.println("Record stored");
	}

	
	
}

