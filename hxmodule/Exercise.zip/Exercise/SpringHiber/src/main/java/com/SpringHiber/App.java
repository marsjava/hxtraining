package com.SpringHiber;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
        EmployeeDao emp=(EmployeeDao)context.getBean("emp");
        Employee e=new Employee(4012621,"Asha",2323.23f);
        
        emp.storeEmp(e);
        System.out.println("data inserted");
    }
}
