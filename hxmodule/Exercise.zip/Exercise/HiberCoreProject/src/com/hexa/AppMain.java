package com.hexa;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;



public class AppMain {

	public static void main(String[] args) {
		
		AnnotationConfiguration se = new AnnotationConfiguration();
		
		SessionFactory e =se.configure().buildSessionFactory();
		
		Session session = e.openSession();
		
		Transaction t = session.beginTransaction();
		
		Student st = new Student();
		
		st.setId(39333);
		st.setName("Sur3");
		session.persist(st);
		t.commit();
		
		Query query=session.createQuery("FROM com.hexa.Student");
		List l =query.list();
		Iterator<Student> itr=l.iterator();
		
		while(itr.hasNext()) {
			st=itr.next();
			System.out.println("id" + st.getId());
			System.out.println("name" + st.getName());
		}
		
		session.close();	

	}

}
