package com.jdbcPrep;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	try{  
    		//step1 load the driver class  
    		Class.forName("oracle.jdbc.driver.OracleDriver");  
    		  
    		//step2 create  the connection object  
    		Connection con=DriverManager.getConnection(  
    		"jdbc:oracle:thin:@172.25.163.114:1521:hyper1","system","Password123");  
    		  String query="select * from emp where eid=?";
    	PreparedStatement psmt =con.prepareStatement(query);
    	psmt.setInt(1,101);
    	ResultSet rs=psmt.executeQuery();
    	while(rs.next()) {
    		int eid=678;
    		String ename=rs.getString(2);
    		int salary =rs.getInt(3);
    		System.out.println(eid +" "+ename+ " "+salary);
    	}
    	}catch(Exception e) {
    		System.out.println(e);
    	}
    	
    		
    	}
}
