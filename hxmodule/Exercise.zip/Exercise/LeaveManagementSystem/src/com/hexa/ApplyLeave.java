package com.hexa;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ApplyLeave
 */
@WebServlet("/ApplyLeave")
public class ApplyLeave extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApplyLeave() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		String sdate = request.getParameter("sdate");
		String edate = request.getParameter("edate");
		String leavetype = request.getParameter("leavetype");
		String leavereason = request.getParameter("levReason");
		String days = request.getParameter("days");
		int d=Integer.parseInt(days);
		out.println(d);
		String eid = request.getParameter("empid");
		int ei=Integer.parseInt(eid);
		try{  
			Class.forName("com.mysql.jdbc.Driver");  
			  
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","Password123");  
			  
			PreparedStatement stmt=con.prepareStatement("insert into LeaveHistory(StartDate,EndDate,LeaveType,LeaveReason,NoOfDays,Emp_Id) values(?,?,?,?,?,?)");  
			stmt.setString(1,sdate);//1 specifies the first parameter in the query  
			stmt.setString(2,edate);  
			stmt.setString(3,leavetype);
			stmt.setString(4,leavereason);
			
			stmt.setInt(5,d);
			stmt.setInt(6,ei);
			int i=stmt.executeUpdate();  
			System.out.println(i+" records inserted");  
			
			
			ResultSet rs=stmt.executeQuery("Select * from emp where emp_Id="+eid);
			while(rs.next()) {  
			int bal=rs.getInt(6)-d;
			out.println(bal);
			  String query1="update emp set Emp_Leave_Bal=? where Emp_Id="+eid;
			  PreparedStatement stmt1=(PreparedStatement)con.prepareStatement(query1);
			  stmt1.setInt(1, bal);
			  stmt1.execute();
			}
			con.close();  
			  
			}catch(Exception e){ System.out.println(e);}  
		RequestDispatcher rd =request.getRequestDispatcher("Success.jsp");
		rd.forward(request,response);
	}

}
