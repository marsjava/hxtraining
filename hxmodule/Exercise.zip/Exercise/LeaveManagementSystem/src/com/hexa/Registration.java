package com.hexa;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Registration
 */
@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Registration() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("reg")!=null){	
			String eid = request.getParameter("eid");
			String ename = request.getParameter("ename");
			String dj = request.getParameter("joindt");
			String dept = request.getParameter("dept");
			String mid = request.getParameter("mgrid");
			String lb = request.getParameter("leavebal");
			String pass = request.getParameter("pass");
			HttpSession hs =request.getSession();
			hs.setAttribute("empname", ename);
			RequestDispatcher rd =request.getRequestDispatcher("Welcome.jsp");
			rd.forward(request,response);
			}
			
		}
			
	}

