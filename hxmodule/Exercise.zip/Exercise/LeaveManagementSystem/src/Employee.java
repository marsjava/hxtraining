
public class Employee {
private int empId;
private String name;
private String joinDate;
private String dept;
private int mgrId;
private int leaveBal;
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getJoinDate() {
	return joinDate;
}
public void setJoinDate(String joinDate) {
	this.joinDate = joinDate;
}
public String getDept() {
	return dept;
}
public void setDept(String dept) {
	this.dept = dept;
}
public int getMgrId() {
	return mgrId;
}
public void setMgrId(int mgrId) {
	this.mgrId = mgrId;
}
public int getLeaveBal() {
	return leaveBal;
}
public void setLeaveBal(int leaveBal) {
	this.leaveBal = leaveBal;
}
}
