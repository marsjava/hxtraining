package com.Spring7;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringDemo {
	 
    public static void main(String a[]){
        String confFile = "Beans.xml";
        ConfigurableApplicationContext context 
                        = new ClassPathXmlApplicationContext(confFile);
        PaymentGateway paymentGateway = (PaymentGateway) context.getBean("paymentGateway");
        System.out.println(paymentGateway.toString());
    }
}
