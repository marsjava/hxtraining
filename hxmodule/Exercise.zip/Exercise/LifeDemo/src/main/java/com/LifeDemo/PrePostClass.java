package com.LifeDemo;



import org.springframework.beans.BeansException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.config.BeanPostProcessor;


public class PrePostClass implements BeanPostProcessor ,DisposableBean  {

	public Object postProcessAfterInitialization(Object bean, String beanName)
			throws BeansException {
		System.out.println("After Initialization "+beanName);
		return bean;
	}

	public Object postProcessBeforeInitialization(Object bean, String beanName)
			throws BeansException {
		 System.out.println("Before Initialization "+ beanName);
		
		return bean;
	}

	public void destroy() throws Exception {
		System.out.println("Objects destroyed");
		
	}

}






