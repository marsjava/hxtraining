package com.LifeDemo;



public class LifeDemo {
	int val;
	public void setVal(int val) {
		this.val = val;
	}
	public int getVal() {
		return val;
	}
	public void abc()
	{
		int a=100;
		val=a;
		System.out.println("We are in init method");
	}
	public void xyz()
	{
		System.out.println("We are in Destroy method");
	}
	

}

