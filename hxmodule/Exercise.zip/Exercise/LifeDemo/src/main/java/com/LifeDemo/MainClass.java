package com.LifeDemo;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
		LifeDemo o=(LifeDemo)context.getBean("xxx");
		System.out.println(o.getVal());
		context.registerShutdownHook();
		

	}

}
